#include <stdio.h>

int Power(int m, int n)
{
 if(n==0)
 {
  return 1;
 }
 return Power(m, n-1)*m;
}



int main(void)
{ 
 int m, n;
 
 printf("m의 n제곱을 구한다.\n");
 printf("m, n 정수 두 개 입력 : ");
 scanf("%d %d", &m, &n);

 printf("%d의 %d승은 %d \n", m, n, Power(m, n));
 return 0;;
}