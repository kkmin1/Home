sum = 0
n = int(input())
for i in range(1,n):
	sum = sum + i
print(sum)	