#include <stdio.h>

int main()
{
char chr, name[64];
while(1){
	scanf(" %c", &chr); // 한 문자 입력후 엔터키치면 이것도 입력으로 받아들여 짐. 이를 방지하기 위해 앞에 공백을 줌
	printf("당신이 입력한 문자는 %c입니다.\n", chr);
	printf("아스키 코드는 %d입니다.\n", chr);
	
	scanf(" %s", name); 
	printf("당신이 입력한 글자는 %s입니다.\n", name);
	}
    return 0;
}