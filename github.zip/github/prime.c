#include <stdio.h>
#include <time.h> // clock() 사용

// 두 정수 사이의 소수를 구한다.

void prime1();
void prime2();

int main(void){

int nStart, nEnd, count = 0;
float exeTime;

nStart = clock(); //밀리세컨드 단위로 시간 측정
int i, j, m, n;

printf("2 이상의 정수 하한, 상한을 한칸 띄어 입력\n");
scanf("%d %d", &m, &n);
printf("하한 : %d,  상한 : %d\n", m, n);

// 상하한이 1 이하면 안됨
if(m <=1 || n <= 1){
	printf("2 이상의 정수를 입력하시오");
	exit(1);
}

// 우선 2부터 n까지의 소수를 구한다.
for (i = 2; i <= n; i++){
      for (j = 2; j <= i; j++)

//반복중에 i를 j로 나눈값이 0이된다면 소수가 아니므로 for문 이탈
           if (i % j == 0)
       break;
  
//반복문을 탈출했는데 i와 j가 같다는 것은 자기자신으로 나눴을때만 0이 나온다는것
//즉, 1과 나 자신 숫자 외에는 나눌수있는 수가 없다는것

// n까지 구한 소수중에 m보다 작은 것은 제거
if (i == j && i >= m){
    printf("%d ", i);
    count++;
    if (count % 10 == 0)
        printf("\n");
    }    
 }
 
 // 수행시간 측정
 nEnd = clock();
 exeTime = (nEnd - nStart)/1000.0;
 printf("\n수행시간 : %.2f(초)", exeTime);
return 0;
}
