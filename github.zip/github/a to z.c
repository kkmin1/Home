#include <stdio.h>

// a부터 z 까지 출력

int main()
{
    char a, c;
    
    for(a = 'a'; a <= 'z'; ++a)
       {printf("%c ", a);}
    printf("\n");
       
    for(c = 'A'; c <= 'Z'; ++c)
       {printf("%c ", c);}
    printf("\n");
    
    return 0;
}
