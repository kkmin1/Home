// package exercise;

// 피라미드 2개 별찍기

public class star2Pyramid {
 
    // 4/4분면에 역피라미드형이 나오려면 1/4분면에 피라미드형이 나와야 함. 열인덱스 j가 데카르트 좌표의 x값을 의미
    public static int func(int j, int n){
        if (j < n)
            return n - j;
        else if (j >= n && j < 2*n)
            return j - n;
        else if (j >= 2*n && j < 3*n)
            return 3*n - j;
        else
            return j - 3*n;
    }

    public static void main(String[] args) {
 
     int n = 10; 

        for (int i = 0; i < n; i++) {
 
            for (int j = 0; j < 4*n; j++) 
                if (i > func(j, n))
                    System.out.print("*");
                else
                    System.out.print(" ");
                
 
            System.out.println();
        }
     }
 }



