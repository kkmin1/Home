#include <stdio.h>

int m = 4; // 줄수
int n = 0; // 왼쪽으로 부터 덜어지는 정도. 디폴트로 0 입력

// 한 줄 출력 함수, m개의 별을 찍는다.
void star(int m)
{
  if(m == 0) return;
  star(m-1);
  printf("*");
}

// 한 줄 출력 함수, n개의 공백을 찍는다.
void space(int n)
{
  if(n == 0) return;
  space(n-1);
  printf(" ");
}

// st 번째 별찍기 함수 출력
void f(int st, int sp)
{
     
    if(st == 0) return;
    f(st-1, sp+1); 
    printf("\n");
    space(sp); 
    star(2*st-1);
    
}

int main()
{
  f(m, n);
  printf("\n");
  return 0;
}