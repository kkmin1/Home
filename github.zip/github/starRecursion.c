#include <stdio.h>

int n;

// 한 줄 출력 함수, k개의 별을 찍는다.
void g(int k)
{
  if(k <= 0) return;
  g(k-1);
  printf("*");
}

// k 번째 별찍기 함수 출력
void f(int k)
{
  if(k <= 0) return;
  f(k-1); // (k-1)번째 별찍기 함수 출력
  g(k); // k 번째 줄 출력
  printf("\n");
}

int main()
{
  printf("숫자를 입력하세요 : ");
  scanf("%d", &n);
  f(n);
  return 0;
}