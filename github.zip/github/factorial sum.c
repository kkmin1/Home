#include <stdio.h>

// 정수 삼각형을 만든 후 n!까지의 합을 구하는 프로그램

int main()
{
    int a = 1, b = 0;
    int i, j, n;

    printf("Enter integer number : ");
    scanf("%d", &n);
    if (n<=0 || n == NULL){
             printf("\n1 이상의 정수를 입력하시오\n");
             exit(1);
    }
    
    printf("%d\n", n);

    for(i=1; i<=n; i++)
    {
    	
    	// 정수 삼각형을 만듬
    	  j = 1;
         while(j < i){
            printf("%d * ", j);
            j++;
            }
        printf("%d", j);
        
        // factorial sum을 구함
        a *= i;
        b += a;
        printf(" = %d\n", a);       
    }
    printf("sum of %d! = %d\n", n, b);
    
    return 0;
}
