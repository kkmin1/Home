# include <stdio.h>

void star(int y, int x, int n);

char arr[3072][6144];

int main(void){
    int n = 12;
    for(int y = 0; y < n; y++){
        for(int x = 0; x < 2*n; x++){
            if(x == 2*n - 1)
                arr[y][x] = '\0'; // 배열은 홑따옴표 사용
            else
                arr[y][x] = ' ';
        }
    }

    star(0, n-1, n);

    // 배열 출력
    for(int y = 0; y < n; y++){
        for(int x = 0; x < 2*n; x++){
            printf("%c", arr[y][x]);
        }
    printf("\n");
    }
return 0;
}

// x, y 좌표 및 행수 n이 주어지면 삼각형을 그리는 재귀함수
void star(int y, int x, int n){
    if (n == 3){
        arr[y][x] = '*';
        arr[y+1][x-1] = '*';
        arr[y+1][x] = '*';
        arr[y+1][x+1] = '*';
        arr[y+2][x-2] = '*';
        arr[y+2][x-1] = '*';
        arr[y+2][x] = '*';
        arr[y+2][x+1] = '*';
        arr[y+2][x+2] = '*';
        return;
    }

    star(y, x, n/2);
    star(y + n/2, x - n/2, n/2);
    star(y + n/2, x + n/2, n/2);

}