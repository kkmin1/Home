#include <stdio.h>

int main()
{
	int i,j, num, n; 
	int result[20]; 

	printf("십진수를 n 진수로 변환하는 프로그램\n");
	printf("변환할 숫자를 입력하세요 : "); 
	scanf("%d", &num);
	printf("진수를 입력하세요 : "); 
	scanf("%d", &n);

	// 10진수를 n 진수로 변환
	for(i = 0; num > 0; i++)
	{
		result[i] = num % n;
		num = num / n;
	}

	printf("변환 결과\n");
	// 역순으로 출력
	for(j = i - 1; j >= 0; j--)
	{
		printf(" %d", result[j]);
	}
	printf("\n");

	return 0;
}
