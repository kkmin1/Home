#include <stdio.h>

int main(void){
char a;
int x, y;

   printf("수식을 입력하세요 :");
   scanf("%d %c %d", &x, &a, &y);
   if(a == '+')
       printf("%d %c %d = %d\n", x, a, y, x+y);
   else if(a == '-')
       printf("%d %c %d = %d\n", x, a, y, x-y);

return 0;
}