#include <stdio.h>  

int main(void) 
{ 
  char ch; 

    printf("프로그램을 종료시키기 위해 한 문자를 입력하세요: "); 
    ch = getchar(); 
    printf("입력한 문자는 %c입니다.\n", ch); 
    getchar(); //입력 버퍼에 엔터를 비워주는 역할 

 while (ch != 'q') {
    printf("잘못된 문자를 입력하였읍니다. 다른 문자를 입력하세요. "); 
    ch = getchar(); 
    printf("입력한 문자는 %c입니다.\n", ch); 
    getchar(); //입력 버퍼에 엔터를 비워주는 역할 
 	}
  printf("정확한 문자를 입력하였읍니다. 프로그램을 종료합니다. "); 
  
 return 0; 
} 