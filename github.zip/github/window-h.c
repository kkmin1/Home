#include <stdio.h>
#include <windows.h>
 
int main( void ){
    printf( "HelloWorld" );
    system( "cls" );
    printf( "HelloWorld" );
 
    return 0;
}

