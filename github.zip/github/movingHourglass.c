#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // sleep() 헤더파일. 윈도우용은 window.h

// 움직이는 모래시계, 효과를 보기위해서는 터미널 깨끗한 전체화면에서 실행할 것
	
// c에서는 bool type이 없기 때문에 만들어 줌
typedef enum {false, true} bool;

bool Pyramid(int n, int x, int y, int k); // 피라미드 내부면 참, 아니면 거짓
bool RevPyramid(int n, int x, int y, int k); // 역피라미드 내부면 참, 아니면 거짓

void gotoxy(int x,int y); // screen (x,y)으로 이동


int main(){
	
int x, y, n = 10;  

    for(int k=0; k <= n; k++){
        gotoxy(0,0);
        for (int y = 0; y >= -n; y--){
            for (int x = 0; x <= 2*n; x++){   
                if (RevPyramid(n, x, y, k))
                    printf("*");
                else
                    printf(" ");
            }
            printf("\n");
        }
        
        for (int y = -n; y >= -2*n; y--){
            for (int x = 0; x <= 2*n; x++){   
                
                if (Pyramid(n, x, y, k))
                    printf("*");
                else
                    printf(" ");
            }
            printf("\n");
        }
        sleep(1); // 1초 중지. windows용은 Sleep(1000)
    }
    return 0;
}

// 역 피라미드 범위를 정한다. 위로부터 한줄씩 사라져야 하므로 k를 포함
bool RevPyramid(int n, int x, int y, int k){
	if (x <= n)
     if (y >= -x && y < -k)
        return true;
     else
        return false;
   else 
     if (y >= x - 2*n && y < -k)
        return true;
     else
        return false;
}

// 피라미드 범위를 정한다. 위로부터 한줄씩 나타나야 하므로 k를 포함
bool Pyramid(int n, int x, int y, int k){	
	if (x <= n)
        if (y <= x - 2*n && y > -k-10)
            return true;
        else
            return false;
    else 
        if (y <= -x && y > -k-10)
            return true;
        else
            return false;
}

// 화면의 x, y 좌표로 이동하는 함수
void gotoxy(int x,int y){
    printf("%c[%d;%df",0x1B,y,x);
}

