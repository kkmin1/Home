#include <stdio.h>

int main()
{
    int age;
    char name[100];
    char c[100];

    gets(c); // 공백있는 문자열 압력시 사용
    printf("You entered: ");
    puts(c); 
  ////////////////////////////////////////////////////////  
  
    scanf("%d", &age);
    scanf("%s", &name);
    printf("이름은 %s이고, 나이는 %d살입니다.\n",name,age);
    
    float d,e,f;

    printf("Enter two real numbers:");
    scanf("%f %f", &d, &e);
    printf(" %.2f  %.2f\n",d,e);
    f=d+e; // 입력이 이루어진 다음에 이 식이 와야 함
    printf("두 수의 합 : %.2f\n", f);
  ////////////////////////////////////////////////////////  
  
    int score;
    scanf("%d", &score);
    printf("당신의 점수은 %d점\n",score);
    if (score > 90)
    printf("당신은 Top 10%\n");
    else
    printf("당신은 Less than 90\n");
    return 0;
}

    
