

$n = 10; // the length of rows
for ($i=0; $i < $n ; $i++) {
  for($j = 0; $j <= $i; $j++ ) {
    echo "*";
  }
  echo "<br>";
}