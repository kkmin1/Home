#include <stdio.h>

int PrintStar(int n){
	if(n==0) return 0;
	printf("*");
	return PrintStar(n-1);
}
int PrintTriangle(int Width,int Height){
	if(Width>Height) return 0;
	PrintStar(Width);
	printf("\n");
	return PrintTriangle(Width+1,Height);
}
int main(){
	int First_Width=1;
	int Height=7;
	PrintTriangle(First_Width,Height);
	return 0;
}