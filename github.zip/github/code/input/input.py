# coding = utf8
name=input("이름 : ")  #input는 입력메서드
age=input("나이:")
print("당신의 이름은", name+"이고 나이는",age+"살입니다.") # , 는 한칸 띄기. 붙여쓸려면 + 사용
