import java.util.*;
import java.lang.*;

public class arraylist2d{
  
public static void main(String[] args){

ArrayList<ArrayList<Integer>> strg = new ArrayList<>();

    
        strg.add(new ArrayList<Integer>()); 
            strg.get(0).add(3);
            strg.get(0).add(2);
            strg.get(0).add(5);

        strg.add(new ArrayList<Integer>());
            strg.get(1).add(2);
            strg.get(1).add(0);
        //    strg.get(1).add(-2);

        for(int i = 0; i < 3; i++)
            strg.add(new ArrayList<Integer>()); 
            for(int j = 0; j < 3; j++)
                strg.get(j).add(2);

System.out.println(strg);
// 출력 : [[3, 2, 5, 2], [2, 0, 2], [2], [], []]

for(int i = 0; i < 4; i++)
    for(int j = 0; j < 4; j++)
        System.out.println(strg.get(i).get(j));
        
}
}