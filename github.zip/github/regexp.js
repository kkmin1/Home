// 자바스크립트 정규표현식

// test() 메소드는 일치여부 참, 거짓으로 판정, exec()는 일치하는 것 찾아줌.

var pattern = /ap*/; // *는 앞에 존재하는 문자 *가 없어도 되고 몇번 반복되도 상관 없음
console.log(pattern.test("apple")); // true
console.log(pattern.exec("apple"));
console.log(pattern.test("ap")); // true
console.log(pattern.exec("ap"));
console.log(pattern.test("ax")); // true
console.log(pattern.exec("ax"));
console.log(pattern.test("apppd")); // true
console.log(pattern.exec("apppd"));
console.log(/o*/.test("abcd")); // true, o이 없어도 되므로 매칭
console.log("\n");

var pattern = /ap?/; // ?는 앞에 존재하는 문자가 있을 수도, 없을 수도 있음
console.log(pattern.test("apple")); // true
console.log(pattern.exec("apple"));
console.log(pattern.test("ap")); // true
console.log(pattern.exec("ap"));
console.log(pattern.test("ax")); // true
console.log(pattern.exec("ax"));
console.log(pattern.test("apppd")); // true
console.log(pattern.exec("apppd"));
console.log(/e?le?/.exec("angel")); // el에 매칭됨
console.log(/e?le?/.exec("oslo")); // l에 매칭됨
console.log("\n");

var pattern = /ap+/; // +는 앞에 존재하는 문자 p가 한번 이상 반복
console.log(pattern.test("apple")); // true
console.log(pattern.exec("apple"));
console.log(pattern.test("ap")); // true
console.log(pattern.exec("ap"));
console.log(pattern.test("ax")); // false
console.log(pattern.exec("ax"));
console.log("\n");

var pattern = /Cook.*Book/; // '/.../' 사이의 값 비교. 
console.log(pattern.test("Sam's Cookbook")); // false. CookBook이 없으므로 
console.log(pattern.exec("Sam's Cookbook")); // null
console.log("\n");

var pattern = /Cook.*Book/i; // i는 대소문자 구분하지 말고 찾아라.
console.log(pattern.test("Sam's Cookbook")); // true. Cookbook 일치. 
console.log(pattern.exec("Sam's Cookbook")); // Cookbook 일치, 최초 일치만 찾음.
console.log("\n");

var pattern = /o/ig; // g는 일치하는 모든 것을 찾음
console.log(pattern.test("Sam's Cookbook")); // true. Cookbook 일치. 

var str = "Sam's Cookbook";
console.log(str.match(pattern)); // [ 'o', 'o', 'o', 'o' ], match()는 모든 결과값을 돌려줌
console.log("\n");

// \는 특수기호, \d는 0부터 9까지의 숫자와 매칭
console.log(/a\d/.exec("ad")); // null
console.log(/a\d/.exec("a1d")); // a1 과 매칭됨
console.log("\n");

// \는 특수기호. \*는 *가 포함되야 함을 의미
console.log(/a\*/.exec("aaaaaaa")); // 매칭되지 않음
console.log(/a\*/.exec("a*aaaaaa")); // a*과 매칭됨
console.log("\n");

// ^는 처음 문자 A와 매칭되야 함
console.log(/^A/.exec("an A")); // 매칭되지 않음
console.log(/^A/.exec("An E")); // 첫번째 'A'와 매칭됨
console.log("\n");

// $는 마지막 문자 t와 매칭되야 함
console.log(/t$/.exec("eater")); // 매칭되지 않음
console.log(/t$/.exec("eat")); // 마지막 문자 't'와 매칭됨
console.log("\n");

// .은 모든 문자에 매칭(단 개행문자 제외)
console.log(/.n/.exec("an apple")); // an에 매칭됨
console.log(/.n/.exec("nay")); // n앞에 문자가 없으므로 매칭되지 않음
console.log("\n");

var str = "2004-959-559 #This is Phone Number";
var re = /#.*$/;
console.log(re.exec(str))
console.log(str.replace(re, ""));  // 문자열 str에서 주석문을 제거
console.log("\n");

var str = "abcde";
var myArray = str.match(/a(b)c(d)/);
console.log(myArray); // abcd가 매치되고 b, d가 기억됨. [ 'abcd', 'b', 'd', index: 0, input: 'abcde' ]
