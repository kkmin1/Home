#include <stdio.h>

void triangle(int n);
void pyramid(int n);

char arr[100][100];

int main(void){
    int n = 6;
    triangle(n);
    pyramid(n);

    
return 0;
}

void triangle(int n){
    for(int y = 0; y < n; y++){
        for(int x = 0; x < n; x++){
            if (y>x)
                arr[y][x] = '*';
            else
                arr[y][x] = ' ';
        }
    }

    // 배열 출력
    for(int y = 0; y < n; y++){
        for(int x = 0; x < n; x++){
            printf("%c", arr[y][x]);
        }
    printf("\n");
    }
}

void pyramid(int n){
    for(int y = n; y > 0; y--){
        for(int x = -n; x < n; x++){
            if (x <= 0 && y < x + n)
                arr[y][x] = '*';
            else if (x > 0 && y < -x + n)
                arr[y][x] = '*';
            else
                arr[y][x] = ' ';
        }
    }

    // 배열 출력
    for(int y = n; y > 0; y--){
        for(int x = -n; x < n; x++){
            printf("%c", arr[y][x]);
        }
    printf("\n");
    }
}