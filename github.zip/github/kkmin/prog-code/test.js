var arr =
[
   ["c1", "c2", "c3", "c4", "c5","c6", "c7"],
   ["cp1", "cp2", "cp3", "cp4", "cp5", "cp6", "cp7"],
   ["cs1", "cs2", "cs3", "cs4", "cs5", "cs6", "cs7"],
   ["g1", "g2", "g3", "g4", "g5", "g6", "g7"],
   ["j1", "j2", "j3", "j4", "j5", "j6", "j7"],
   ["py1", "py2", "py3", "py4", "py5", "py6", "py7"],
   ["pl1", "pl2", "pl3", "pl4", "pl5", "pl6", "pl7"]
];

var fname = "test.txt";
var p = "p";
var pre = "pre";
var sharp = "#";
var div = "div";
var sp = " ";
var sel = div+sharp+arr[0][0];
var url = fname+sp+p+sharp+arr[0][0];
var txt = "";

txt += "<select>"
for (x in myObj) {
    txt += "<option>" + myObj[x].name;
}
txt += "</select>"
document.getElementById("demo").innerHTML = txt;
