// 주석

object Scala_hello // 자바와 같이 파일명과 객체명이 같아야 함.
{
  def main(args: Array[String]) {
    println("Hello, world!")
    println("안녕하세요!")
  }
}
