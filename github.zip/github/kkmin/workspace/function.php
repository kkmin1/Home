<html>
<head></head>
<body>
<?php
function hello(){
    echo "안녕하세요<br>";
}
hello();

function sum($num1,$num2){
    echo "Addition of two numbers is ".($num1+$num2)."<br>";
}
sum(12,56);
?>
</body>
</html>