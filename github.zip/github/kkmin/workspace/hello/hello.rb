# 주석
puts 'Hello, world!'
puts "안녕하세요!"
