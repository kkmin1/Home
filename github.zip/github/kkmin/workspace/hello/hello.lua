--주석--
print("Hello World")
print("안녕하세요!")
