// 코멘트
// 컴파일 >> go build -o go-hello.out hello.go
// run >> ./go-hello.out

package main

import "fmt"

func main() {
    fmt.Printf("hello, world\n")
    fmt.Printf("안녕하세요\n")
}
