// 주석

#include <stdio.h>

int main()
{
   printf("Hello, World!\n");
   printf("안녕하세요!\n");
   return 0;
}
