// 주석 
// 컴파일 >> javac hello.java
// run >> java hello

public class hello {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
        System.out.println("안녕하세요!");
    }
}
