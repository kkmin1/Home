// 주석

#include <iostream>
using namespace std;

int main() 
{
    cout << "Hello, World!\n";  // \n은 c식 줄바꿈
    cout << "안녕하세요!"<< endl; // << endl은 c++에서 줄바꿈 
    return 0;
}
