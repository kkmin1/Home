// comment
/*
compile >> kotlinc hello.kt -include-runtime -d hello.jar
run     >> java -jar hello.jar
*/

fun main(args: Array<String>) {
	println("Hello, World!")
       println("안녕하세요")
}
