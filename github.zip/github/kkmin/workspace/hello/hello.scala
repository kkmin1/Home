// comment
   /* This is my first java program.  
    * This will print 'Hello World' as the output
    */
    	
object Dcoder {

   def main(args: Array[String]) {
      println("Hello, !") 
   }
}
