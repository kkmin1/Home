<html>
<head> <title>Hello World</title> 
<meta charset="utf8">
</head>  

<body> 
<?php 
// comment
echo "Hello, World!"."<br>";
echo "안녕하세요!"."<br>";
?>

 </body>  
</html>
