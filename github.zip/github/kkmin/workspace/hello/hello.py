# 주석

print("Hello, World!") # 자동 줄바꿈 
print("안녕하세요!")
print("민", end="") # 자동 줄바꿈 안함
print("관기")
