


<?php

echo  $_POST['name']. "님, ";
echo "당신은 ". $_POST['age']. "살 입니다.";

?>