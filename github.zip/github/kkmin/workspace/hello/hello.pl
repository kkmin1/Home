# 주석 
print "Hello world!\n";
print "안녕하세요 \n";
