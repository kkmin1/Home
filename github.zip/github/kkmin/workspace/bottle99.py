#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
"""
99 Bottles of Beer (by Gerold Penz)
Python can be simple, too :-)
"""

for quant in range(99, 0, -1):
   if quant > 1:
      print (quant, "bottles of beer on the wall,", quant, "bottles of beer.")
      if quant > 2:
         suffix = str(quant - 1) + " bottles of beer on the wall."
      else:
         suffix = "1 bottle of beer on the wall."
   elif quant == 1:
      print ("1 bottle of beer on the wall, 1 bottle of beer.")
      suffix = "no more beer on the wall!"
   print ("Take one down, pass it around,", suffix)
   print ("--")
