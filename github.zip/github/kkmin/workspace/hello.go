// 주석 

package main 
import "fmt" 
func main() { // In Golang, Opening brace can't be placed on a separate line.
    fmt.Println("Hello, world!") 
    fmt.Println("안녕하세요!") 
}
