# coding = "utf8"
a=input("성 : ")
b=input("이름:")
print("안녕하세요", a+b+"님") # , 는 한 칸 띄기. 붙여쓸려면 + 사용
