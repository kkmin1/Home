$(function(){
    $("p#c1").click(function(){
        $("#center").load("code.txt pre#c1");
    });
    
    $("p#c2").click(function(){
        $("#center").load("code.txt pre#c2");
    });
    
    $("p#cp1").click(function(){
        $("#center").load("code.txt pre#cp1");
    });
    
    $("p#cp2").click(function(){
        $("#center").load("code.txt pre#cp2");
    });
    
    $("p#cs1").click(function(){
        $("#center").load("code.txt pre#cs1");
    });
    
    $("p#cs2").click(function(){
        $("#center").load("code.txt pre#cs2");
    });
    
    $("p#j1").click(function(){
        $("#center").load("code.txt pre#j1");
    });
    
    $("p#j2").click(function(){
        $("#center").load("code.txt pre#j2");
    });
    
    $("p#py1").click(function(){
        $("#center").load("code.txt pre#py1");
    });
    
    $("p#py2").click(function(){
        $("#center").load("code.txt pre#py2");
    });
    
    $("p#pl1").click(function(){
        $("#center").load("code.txt pre#pl1");
    });
    
    $("p#r1").click(function(){
        $("#center").load("code.txt pre#r1");
    });
    
    $("p#h1").click(function(){
        $("#center").load("code.txt pre#h1");
    });
    
    $("p#ph1").click(function(){
        $("#center").load("code.txt pre#ph1");
    });
    
    $("p#js1").click(function(){
        $("#center").load("code.txt pre#js1");
    });
    
    $("p#jq1").click(function(){
        $("#center").load("code.txt pre#jq1");
    });
    
    $("p#k1").click(function(){
        $("#center").load("code.txt pre#k1");
    });
    
    $("p#s1").click(function(){
        $("#center").load("code.txt pre#s1");
    });

    $("p#l1").click(function(){
       $("#center").load("code.txt pre#l1");
    });

    $("p#jl1").click(function(){
       $("#center").load("code.txt pre#jl1");
    });

    $("p#g1").click(function(){
       $("#center").load("code.txt pre#g1");
    });
    
    $("p#rs1").click(function(){
       $("#center").load("code.txt pre#rs1");
    });
    
    $("p#ex1").click(function(){
       $("#center").load("code.txt pre#ex1");
    });
    
    $("p#cl1").click(function(){
       $("#center").load("code.txt pre#cl1");
    });
    
    $("p#ns1").click(function(){
       $("#center").load("code.txt pre#ns1");
    });

});
