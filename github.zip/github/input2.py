# 실수 2개를 두줄에 입력
A = float(input()) #input값은 문자열로 인식되므로 실수로 형변환함
B = float(input())
print (A-B)

# 정수 2개를 한줄에 입력. 공백으로 구분
a,b = map(int, input().split()) #map은 리스트를 모두 형변환할 때 씀. 정수로 형변환
print(a-b)

c, d = map(eval, input().split()) # eval은 입력형에 따라 자동 형변환
print(c-d)