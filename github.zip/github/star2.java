// package exercise;

// 다이아몬드형 별찍기

public class star2 {
 
    public static void main(String[] args) {
 
     int n = 10; 

     // 오른쪽 붙은 직각 삼각형
        for (int i = 0; i < n; i++) {
 
            for (int j = 0; j < n; j++) 
                if (i > n - j)
                    System.out.print("*");
                else
                    System.out.print(" ");
                
 
            System.out.println();
        }
 
       
    }
 
}



