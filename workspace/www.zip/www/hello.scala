object Dcoder {
   /* This is my first java program.  
    * This will print 'Hello World' as the output
    */
   def main(args: Array[String]) {
      println("Hello, world!") // prints Hello World
      println("안녕하세요")
   }
}
