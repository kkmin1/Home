puts("이름 : ")  // 줄바꿈
name=gets
print("당신의 이름은 ") // 줄 바꿈 안됨
print(name)
print("입니다.\n")

print("당신의 이름은 ",name,"입니다.")
