age = 20
name = 'Swaroop'

print('{0} was {1} years old when he wrote this book'.format(name, age))

print(name+" is "+str(age)+" years old") # 그냥 age를 쓰면 error남. str()로 문자열로 만들어야 함


i=0
while i<=10:
  print(i, end='') # end=''  개행
  i=i+1
print()
  
print("안녕" "하세요")
print("안녕"+"하세요")
print("안녕", "하세요") #,는 띄어쓰기

while True:
    a=int(input("숫자를 입력하세요: "))
# input는 입력하는 모든 것을 문자열로 취급한다. 숫자를 입력해도 문자로 취급하므로 숫자화하는 함수인 int()를 사용

    if a<=10:
    	print("당신이 입력한 숫자는 "+str(a)+"입니다.")
        break
    else:
        print("10보다 작은 수를 입력하세요")
        
print("-"*20)
print("두 수를 입력하시오")
print("숫자1:")
a=int(input())
print("숫자2:")
b=int(input())
print("다음 중 선택하세요")

def add(a,b)
     return a+b
def minus(a,b)
     return a-b
def list(a,b)
     return [a,b]
prompt = """
 1. Add
 2. Del
 3. List
 4. Quit

 Enter number: """
 c=int(input())
 choice={1:add, 2:minus, 3:list, 4:quit}
 try:
     choice[c]()
except KeyError:
    print("No data")