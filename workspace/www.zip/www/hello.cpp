// one line comment
/* 
multiline comment
This Program prints Hello World on screen 
*/

#include <iostream>
#include <string>     // Need this header to use string class

using namespace std;
int main ()
{
cout << "Hello World!\n"; // \n은 개행
cout << "안녕하세요!" << endl; // << endl은 개행

int age = 55;
double pyung = 32.5;
string message("안녕하세요");
string name = "민관기";

cout << message << endl;
cout << name << "님, 당신의 나이는 " << age << "살 입니다." << endl;
cout << "당신의 집 크기는 " << pyung << "평입니다." << endl;
return 0;
}
