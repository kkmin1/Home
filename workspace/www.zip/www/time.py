import datetime
print datetime.date.today().strftime("%d:%m:%y")