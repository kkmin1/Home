<!DOCTYPE html>
<html>
<head>
<meta charset = "utf8">
<style> 
h1{
	text-align:center;
	}
	
div#code{
	float:left;
	width:60%;
	height:400px;
	background:gray;
	padding:10px;
	}
	
div#link{
	float:left;
	width:20%;
	height:100%;
	background:gray;
	border:1px solid green; 
	}
div#language{
	float:left;
	width:20%;
	height:100%;
	background:gray;
	border:1px solid green; 
	margin-right:10px;
	}
	
header {
     height:70px;
     background:#ccc;
     padding:10px;
     }

footer {
    position:absolute;
    bottom:0;
    width:100%;
    height:70px;   
    background:#ccc;
    padding:10px;
    }
</style>
</head>
<body>
<header>
<h1>프로그램 언어</h1>
</header>
<div id="language">
<h1>프로그램 언어</h1>
</div>
<div id="code">
<code>
<pre>
#include <stdio.h> 
	
int main(void)
{
    printf("안녕하세요 /n");
    return 0;
}
</pre>
</code>
</div>
<div id="link">
<h1>링크</h1>
</div>
<footer>
 <?php
echo "<p>Copyright &copy; created by kkmin</p>";
?>
</footer>
</body>
</html>
