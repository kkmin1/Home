def f(x): return {'a': '1', 'b': '2'}[x]
print(f("a"))
print(f("b"))