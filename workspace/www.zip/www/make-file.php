<?php
/* 
// 이 파일을 실행하면 phpfile.txt라는 파일을 새로 만들어서 그 안에 '안녕하세요' 문장 추가. phpfile.txt라는 파일이 이미 있으면 기존의 것에 덮어 쓴다.*/

$myfile = fopen("phpfile.txt", "w") 
or die("Unable to open file!");

$txt = "안녕하세요!\n";
fwrite($myfile, $txt);
fclose($myfile);
?>