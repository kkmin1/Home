# define a class, 첫 글자는 항상 대문자

class Sample1
   def hello # 메소드 이름은 소문자 선호
      puts "Hello Ruby!"
      puts "안녕하세요" 
   end
end

# 객체 생성
obj = Sample1. new
obj.hello

class Sample2
   def self.hello
      puts "Hello Ruby!"
      puts "안녕하세요" 
   end
end

Sample2.hello # class method에서는 객체를 생성 안하고 바로 클래스에 연결하여 사용 가능

class Box
  # constructor method
   def initialize(w,h)  # initialize()는 initialize method
      @width, @height = w, h # 메소드 변수앞에 @를 붙임
   end
   
   
   # accessor methods
   def printWidth
      @width
   end

   def printHeight
      @height
   end
end

box = Box.new(10, 20)

# use accessor methods
x = box.printWidth()
y = box.printHeight()

puts "Width of the box is : #{x}"
puts "Height of the box is : #{y}"

class Customer
   @@no_of_customers = 0 # 클래스 변수 앞에는 @@를 붙임
   def initialize(id, name, addr)
      @cust_id = id
      @cust_name = name
      @cust_addr = addr
   end
   def a1; @cust_id; end
   def a2; @cust_name; end
   def a3; @cust_addr; end
end

cust1 = Customer.new("1", "John", "Wisdom Apartments, Ludhiya")
cust2 = Customer.new("2", "민관기", "서울, 마포, 합정동")
puts cust1.a1, cust1.a2, cust1.a3
print cust2.a1, cust2.a2, cust2.a3
