
a=input("성 : ")
b=input("이름:")
print("안녕하세요", a+b+"님") # , 는 한칸 띄기. 붙여쓸려면 + 사용

name = input("What's your name? ") 
print("Nice to meet you " + name + "!") 
age = input("Your age? ") #정수를 입력
print("So, you are already " + age + " years old, " + name + "!")
