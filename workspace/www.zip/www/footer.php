 <?php
echo "<p>Copyright &copy; 1999-" . date("Y") . " W3Schools.com</p>";
?>