//Hello world example code.

#include <stdio.h>

int main()
{
	printf("안녕!!\n");
	return 0;
}
