import classmod
jane = classmod.Amazon()
mary = classmod.Amazon()
jane.strength
jane.attack()
mary.strength
mary.attack()

eve = diablo2.Amazon()
eve.exercise()
eve.strength